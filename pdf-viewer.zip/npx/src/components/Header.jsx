function Header() {
  return (
    <div className="title">
      <p className="web-page">
        PDF-VIEWER 
      </p>
    </div>
  );
}

export default Header;
